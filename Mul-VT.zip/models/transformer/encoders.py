from torch.nn import functional as F
from models.transformer.utils import PositionWiseFeedForward,PositionWiseFeedForward2
import torch
from einops import rearrange, repeat
from torch import nn, einsum
import numpy as np


from models.transformer.attention import MultiHeadAttention
def exists(val):
    return val is not None


class EncoderLayer(nn.Module):
    def __init__(self, d_model=512, d_k=64, d_v=64, h=8, d_ff=2048, dropout=.1, identity_map_reordering=False,
                 attention_module=None, attention_module_kwargs=None):
        super(EncoderLayer, self).__init__()
        self.identity_map_reordering = identity_map_reordering
        self.mhatt = MultiHeadAttention(d_model, d_k, d_v, h, dropout, identity_map_reordering=identity_map_reordering,can_be_stateful=False,
                                           attention_module=None,
                                           attention_module_kwargs=None)
        self.msgm = MSGM()
        self.mhatt1 = MultiHeadAttention(d_model, d_k, d_v, h, dropout, identity_map_reordering=identity_map_reordering,can_be_stateful=False,
                                           attention_module=None,
                                           attention_module_kwargs=None)
        self.imgtxtatt=MultiHeadAttention1(d_model,h,dropout)
        self.attn = Attention(d_model, d_model, d_k, causal=True) if exists(d_k) else None
        self.Fmhatt = SpatialGatingUnit(d_model, 50, causal=True, heads=h, circulant_matrix=True)
        self.pwff = PositionWiseFeedForward(d_model, 1024, dropout, identity_map_reordering=identity_map_reordering)
        self.obj_mlp1 = nn.Sequential(
            nn.LayerNorm(d_model*2), nn.Linear(d_model*2, d_model), nn.Dropout(p=dropout)
        )

    def forward(self, queries, txt1, txt2, ctx_t, img1):  # forword(self, queries, keys, values,img1,prev)
        gate_res = self.attn(queries) if exists(self.attn) else None

        attobj = self.Fmhatt(queries, gate_res=gate_res)
        gate_res2 = self.attn(img1) if exists(self.attn) else None

        attimg = self.Fmhatt(img1, gate_res=gate_res2)

        att1 = torch.concat([attobj, attimg],dim=2)
        att1=self.obj_mlp1(att1)

        att = self.msgm(att1, txt1, txt2, ctx_t)
        ff = self.pwff(att)
        return ff


class MultiLevelEncoder(nn.Module):
    def __init__(self, N, padding_idx, d_model=512, d_k=64, d_v=64, h=8, d_ff=2048, dropout=.1,
                 identity_map_reordering=False, attention_module=None, attention_module_kwargs=None):
        super(MultiLevelEncoder, self).__init__()
        self.d_model = d_model
        self.dropout = dropout
        self.layers = nn.ModuleList([EncoderLayer(d_model, d_k, d_v, h, d_ff, dropout,
                                                  identity_map_reordering=identity_map_reordering,
                                                  attention_module=attention_module,
                                                  attention_module_kwargs=attention_module_kwargs)
                                     for _ in range(N)])
        self.padding_idx = padding_idx

    def forward(self, obj_embed, img1, txt1, txt2, ctx_t, attention_weights=None):
        # input (b_s, seq_len, d_in)
        attention_mask = (torch.sum(torch.abs(obj_embed), -1) == self.padding_idx).unsqueeze(1).unsqueeze(
            1)  # (b_s, 1, 1, seq_len)
        prev = None
        prev1 = None
        outs = []
        out = input
        for l in self.layers:
            # out,prev = l(obj_embed, ctx_t, ctx_t,img1,prev)
            out = l(obj_embed, txt1, txt2, ctx_t, img1)
            # outs.append(out.unsqueeze(1))

        # outs = torch.cat(outs, 1)
        return out, attention_mask


class MemoryAugmentedEncoder(MultiLevelEncoder):
    def __init__(self, N, padding_idx, d_in=2048, **kwargs):
        super(MemoryAugmentedEncoder, self).__init__(N, padding_idx, **kwargs)

    def forward(self, obj_embed, img1, txt1, txt2, ctx_t, attention_weights=None):
        return super(MemoryAugmentedEncoder, self).forward(obj_embed, img1, txt1, txt2, ctx_t,
                                                           attention_weights=attention_weights)


class MultiHeadAttention1(nn.Module):
    def __init__(self, d_model=512, n_heads=8, d_k=64, d_v=64, dropout=.1, ):
        super(MultiHeadAttention1, self).__init__()
        self.W_Q = nn.Linear(d_model, d_model, bias=False)
        self.W_K = nn.Linear(d_model, d_model, bias=False)
        self.W_V = nn.Linear(d_model, d_model, bias=False)
        self.fc = nn.Linear(d_model, d_model, bias=False)
        self.layer_norm = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(p=dropout)
        self.d_model = 512
        self.d_k = 64
        self.d_v = 64
        self.n_heads = 8

    def forward(self, input_Q, input_K, input_V, attn_mask=None):
        '''
        input_Q: [batch_size, len_q, d_model]
        input_K: [batch_size, len_k, d_model]
        input_V: [batch_size, len_v(=len_k), d_model]
        attn_mask: [batch_size, seq_len, seq_len]
        '''
        residual, batch_size = input_Q, int(input_Q.size(0))
        nk = input_K.shape[1]
        # (B, S, D) -proj-> (B, S, D_new) -split-> (B, S, H, W) -trans-> (B, H, S, W)
        Q = self.W_Q(input_Q).view(batch_size, -1, self.n_heads, self.d_k).transpose(1,
                                                                                     2)  # Q: [batch_size, n_heads, len_q, d_k]
        K = self.W_K(input_K).view(batch_size, -1, self.n_heads, self.d_k).transpose(1,
                                                                                     2)  # K: [batch_size, n_heads, len_k, d_k]
        V = self.W_V(input_V).view(batch_size, -1, self.n_heads, self.d_v).transpose(1,
                                                                                     2)  # V: [batch_size, n_heads, len_v(=len_k), d_v]

        # attn_mask = attn_mask.unsqueeze(1).repeat(1, n_heads, 1, 1) # attn_mask : [batch_size, n_heads, seq_len, seq_len]
        attn_mask = (torch.sum(torch.abs(input_K), dim=-1) == 0).unsqueeze(1).unsqueeze(1)
        # context: [batch_size, n_heads, len_q, d_v], attn: [batch_size, n_heads, len_q, len_k]
        scores = torch.matmul(Q, K.transpose(-1, -2)) / np.sqrt(self.d_k)

        scores[:, :, :, :nk] = scores[:, :, :, :nk].masked_fill(attn_mask, -np.inf)
        attn = nn.Softmax(dim=-1)(scores)
        context = torch.matmul(attn, V)
        context = context.transpose(1, 2).reshape(batch_size, -1,
                                                  self.n_heads * self.d_v)  # context: [batch_size, len_q, n_heads * d_v]
        output = self.fc(context)  # [batch_size, len_q, d_model]
        output = self.dropout(output)
        output = self.layer_norm(output + residual)
        return output


class Attention(nn.Module):
    def __init__(self, dim_in, dim_out, dim_inner, causal=False):  # 如果有att-dim，dim—in 512 dim-out 1024
        super().__init__()
        self.scale = dim_inner ** -0.5
        self.causal = causal
        self.to_qkv = nn.Linear(dim_in, dim_inner * 3, bias=False)
        self.to_out = nn.Linear(dim_inner, dim_out)

    def forward(self, x):
        device = x.device
        q, k, v = self.to_qkv(x).chunk(3, dim=-1)
        sim = einsum('b i d, b j d -> b i j', q, k) * self.scale
        if self.causal:
            mask = torch.ones(sim.shape[-2:], device=device).triu(1).bool()
            sim.masked_fill_(mask[None, ...], -torch.finfo(q.dtype).max)

        attn = sim.softmax(dim=-1)

        out = einsum('b i j, b j d -> b i d', attn, v)

        return self.to_out(out)


class SpatialGatingUnit(nn.Module):
    # 定义初始化方法，接受以下参数：
    # dim: 输入和输出的维度
    # dim_seq: 空间维度（token数）
    # causal: 是否使用因果掩码
    # act: 激活函数，默认为恒等函数
    # heads: 多头注意力的头数
    # init_eps: 初始化权重时的范围（-init_eps, init_eps）
    # circulant_matrix: 是否使用循环矩阵作为权重矩阵
    def __init__(
            self,
            dim,
            dim_seq,
            causal=False,
            act=nn.Identity(),
            heads=1,
            init_eps=1e-3,
            circulant_matrix=False
    ):
        super().__init__()
        dim_out = dim
        self.heads = heads
        self.causal = causal
        self.norm = nn.LayerNorm(dim_out)

        self.act = act
        # self.line=nn.Linear(dim, dim_out)
        # parameters
        # self-atten 用的dim
        # sgu用的dim_ff = dim * ff_mult（4），即4倍
        # chunk之后，每个为2倍，用两倍的值进行attention
        # 如果使用循环矩阵，则定义两个参数，表示循环矩阵的位置编码，并初始化为全1向量
        # 否则，定义一个参数，表示权重矩阵，并初始化为全0张量
        if circulant_matrix:
            self.circulant_pos_x = nn.Parameter(torch.ones(heads, dim_seq))
            self.circulant_pos_y = nn.Parameter(torch.ones(heads, dim_seq))

        self.circulant_matrix = circulant_matrix
        shape = (heads, dim_seq,) if circulant_matrix else (heads, dim_seq, dim_seq)
        weight = torch.zeros(shape)

        self.weight = nn.Parameter(weight)
        init_eps /= dim_seq
        nn.init.uniform_(self.weight, -init_eps, init_eps)

        self.bias = nn.Parameter(torch.ones(heads, dim_seq))

    def forward(self, x, gate_res=None):
        device, n, h = x.device, x.shape[1], self.heads  # n dim_sep(src_len)

        # res, gate = x.chunk(2, dim = -1) #分块 在dim_sep这个维度  res和gate 相当于伪代码中的u，v
        res = x
        gate = x
        gate = self.norm(gate)
        weight, bias = self.weight, self.bias

        if self.circulant_matrix:
            # build the circulant matrix

            dim_seq = weight.shape[-1]
            # 在最后一个维度上对权重矩阵进行填充，使其形状为(heads, dim_seq * 2)
            weight = F.pad(weight, (0, dim_seq), value=0)
            # 在最后一个维度上重复权重矩阵dim_seq次，使其形状为(heads, dim_seq * dim_seq * 2)
            weight = repeat(weight, '... n -> ... (r n)', r=dim_seq)
            # 截取最后一个维度上的前dim_seq个元素，使其形状为(heads, dim_seq * dim_seq)
            weight = weight[:, :-dim_seq].reshape(h, dim_seq, 2 * dim_seq - 1)
            # 截取最后一个维度上的后dim_seq个元素，使其形状为(heads, dim_seq * dim_seq)
            weight = weight[:, :, (dim_seq - 1):]

            # give circulant matrix absolute position awareness

            pos_x, pos_y = self.circulant_pos_x, self.circulant_pos_y
            weight = weight * rearrange(pos_x, 'h i -> h i ()') * rearrange(pos_y, 'h j -> h () j')
        # 如果使用因果掩码，则在权重矩阵的下三角部分填充负无穷大，以避免未来信息的泄露
        if self.causal:
            weight, bias = weight[:, :n, :n], bias[:, :n]
            mask = torch.ones(weight.shape[-2:], device=device).triu_(1).bool()
            mask = rearrange(mask, 'i j -> () i j')
            weight = weight.masked_fill(mask, 0.)

        gate = rearrange(gate, 'b n (h d) -> b h n d', h=h)

        gate = einsum('b h n d, h m n -> b h m d', gate, weight)
        gate = gate + rearrange(bias, 'h n -> () h n ()')

        gate = rearrange(gate, 'b h n d -> b n (h d)')

        if exists(gate_res):
            gate = gate + gate_res

        return self.act(gate) * res


def linear_layer(in_dim, out_dim):
    return nn.Sequential(nn.Linear(in_dim, out_dim),
                         nn.LayerNorm(out_dim), nn.ReLU(True))


class MSGM(nn.Module):
    def __init__(self,
                 in_channels=[512, 1024, 1024],
                 out_channels=[256, 512, 1024]):
        super(MSGM, self).__init__()
        # text projection
        # fusion 1: v5 & seq -> f_5: b, 1024, 13, 13
        self.f1_v_proj = linear_layer(in_channels[0], out_channels[1])
        self.norm_layer = nn.Sequential(nn.LayerNorm(out_channels[1]),
                                        nn.ReLU(True))
        # fusion 2: v4 & fm -> f_4: b, 512, 26, 26
        self.f2_v_proj = linear_layer(in_channels[0], out_channels[1])
        self.f2_cat = linear_layer(out_channels[1] + out_channels[1],
                                   out_channels[1])
        # fusion 3: v3 & fm_mid -> f_3: b, 512, 52, 52
        self.f3_v_proj = linear_layer(in_channels[0], out_channels[1])
        self.f3_cat = linear_layer(out_channels[1] + out_channels[1],
                                   out_channels[1])
        # fusion 4: f_3 & f_4 & f_5 -> fq: b, 256, 26, 26
        # self.f4_proj5 = linear_layer(out_channels[1], out_channels[1])
        # self.f4_proj4 = linear_layer(out_channels[1], out_channels[1])
        # self.f4_proj3 = linear_layer(out_channels[1], out_channels[1])
        # aggregation
        self.aggr = linear_layer(3 * out_channels[1], out_channels[1])

    def forward(self, imgs, text1, text2, text3):
        # v3, v4, v5: 50, 108, 512 / 50, 60, 512 / 50, 12, 512
        v3, v4, v5 = text3, text2, text1
        # fusion 1: b, 1024, 50
        # text projection: b, 1024 -> b, 1024
        f5 = self.f1_v_proj(v5)
        f5 = F.interpolate(f5.permute(0, 2, 1), size=50, mode='linear').permute(0, 2, 1)
        f5 = self.norm_layer(f5 * imgs)  # b, 1024, 50
        # fusion 2: b, 512, 60
        f4 = self.f2_v_proj(v4)
        f4_ = F.interpolate(f4.permute(0, 2, 1), size=50, mode='linear').permute(0, 2, 1)
        f4_ = self.norm_layer(f4_ * imgs)
        f4 = self.f2_cat(torch.cat([f4_, f5], dim=2))
        # fusion 3: b, 256, 108
        f3 = self.f3_v_proj(v3)
        f3 = F.interpolate(f3.permute(0, 2, 1), size=50, mode='linear').permute(0, 2, 1)
        f3 = self.norm_layer(f3 * imgs)
        f3 = self.f3_cat(torch.cat([f3, f4], dim=2))
        # fusion 4: b, 512, 13, 13 / b, 512, 26, 26 / b, 512, 26, 26
        # fq5 = self.f4_proj5(f5)
        # fq4 = self.f4_proj4(f4)
        # fq3 = self.f4_proj3(f3)
        # query
        fq = torch.cat([f3, f4, f5], dim=2)
        fq = self.aggr(fq)

        # b, 512, 26, 26
        return fq

